AMP ALGORITHMS: C++ AMP Algorithms Library
 
This library contains collections of C++ AMP algorithms that can be useful building 
blocks for C++ AMP applications. 

The library is in the form of C++ header files that are available in "inc" directory. 
Further documentation and a Getting Started guide can be found on the CodePlex site's 
Documentation page.

https://ampalgorithms.codeplex.com/documentation
